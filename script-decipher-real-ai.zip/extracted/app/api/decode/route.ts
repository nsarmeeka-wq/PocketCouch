import { NextRequest, NextResponse } from 'next/server'
import type Anthropic from '@anthropic-ai/sdk'
import { anthropicClient, decodeModel, parseJsonResponse, DecodeError } from '@/lib/ai'

export const runtime = 'nodejs'
export const maxDuration = 60

const ALLOWED_MEDIA_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'] as const
type AllowedMediaType = (typeof ALLOWED_MEDIA_TYPES)[number]

type DecodeResult = {
  script: string
  language: string
  transcription: string
  translation: string
  subject: string
  confidence: number
  notes: string
}

const PROMPT_TEMPLATE = (targetLanguage: string) => `You are assisting a manuscript-digitization research tool. You will be shown a photograph of a page that is most likely handwritten or printed in an Indian script (Devanagari, Tamil, Bengali, Kannada, Telugu, Odia, or Perso-Arabic), though it could be another script, language, or not a manuscript at all.

Look at the image carefully and respond with ONLY a single JSON object — no markdown fences, no commentary before or after — with exactly these fields:

{
  "script": string, one of "Devanagari" | "Tamil" | "Bengali" | "Kannada" | "Telugu" | "Odia" | "Perso-Arabic" | "Other",
  "language": string, your best guess at the language (e.g. "Sanskrit", "Hindi", "Tamil", "Bengali", "Unknown"),
  "transcription": string, the visible text transcribed into Unicode exactly as written, preserving line breaks as \\n. If nothing is legible, use an empty string.
  "translation": string, a natural, faithful translation of the transcription into ${targetLanguage}. If the transcription is empty, use an empty string.
  "subject": string, a short (3-6 word) neutral description of the apparent subject or genre based only on the visible content (e.g. "devotional verse", "medical text", "personal letter"). Do not guess date, origin, or authorship.
  "confidence": integer 0-100, your honest confidence that the transcription is accurate given image quality and script legibility.
  "notes": string, one short sentence flagging anything uncertain, damaged, ambiguous, or illegible. Empty string if there is nothing notable.
}

Rules:
- Never invent or complete text you cannot actually read in the image. If a word or line is illegible, say so in "notes" rather than guessing convincing-looking text.
- If the image is not a manuscript, is blank, or contains no legible script, set "script" to "Other", leave "transcription" and "translation" empty, set "confidence" low, and explain what you actually see in "notes".
- Do not fabricate historical facts (century, region, author) anywhere in your response.`

export async function POST(req: NextRequest) {
  const anthropic = anthropicClient()
  if (!anthropic) {
    return NextResponse.json(
      { error: 'This server is missing ANTHROPIC_API_KEY. Add it to your environment (see .env.example) and restart the app.' },
      { status: 500 },
    )
  }

  let body: { image?: string; targetLanguage?: string }
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: 'Invalid request body.' }, { status: 400 })
  }

  const { image, targetLanguage = 'English' } = body
  if (!image || typeof image !== 'string') {
    return NextResponse.json({ error: 'An image is required.' }, { status: 400 })
  }

  const match = image.match(/^data:([^;]+);base64,(.+)$/)
  if (!match || !ALLOWED_MEDIA_TYPES.includes(match[1] as AllowedMediaType)) {
    return NextResponse.json({ error: 'Unsupported image format. Please use JPG, PNG, WEBP, or GIF.' }, { status: 400 })
  }
  const [, mediaType, base64Data] = match

  // Roughly bound request size (base64 is ~33% larger than the raw bytes).
  if (base64Data.length > 15 * 1024 * 1024) {
    return NextResponse.json({ error: 'Image is too large to decode. Please use an image under 10 MB.' }, { status: 413 })
  }

  try {
    const message = await anthropic.messages.create({
      model: decodeModel(),
      max_tokens: 4000,
      messages: [
        {
          role: 'user',
          content: [
            { type: 'image', source: { type: 'base64', media_type: mediaType as AllowedMediaType, data: base64Data } },
            { type: 'text', text: PROMPT_TEMPLATE(targetLanguage) },
          ],
        },
      ],
    })

    const textBlock = message.content.find((block): block is Anthropic.TextBlock => block.type === 'text')
    if (!textBlock) throw new DecodeError('The model did not return a text response.')

    let parsed: Partial<DecodeResult>
    try {
      parsed = parseJsonResponse<Partial<DecodeResult>>(textBlock.text)
    } catch {
      throw new DecodeError('Could not parse the model\u2019s response. Please try again.')
    }

    const result: DecodeResult = {
      script: parsed.script ?? 'Other',
      language: parsed.language ?? 'Unknown',
      transcription: parsed.transcription ?? '',
      translation: parsed.translation ?? '',
      subject: parsed.subject ?? '',
      confidence: typeof parsed.confidence === 'number' ? Math.max(0, Math.min(100, Math.round(parsed.confidence))) : 0,
      notes: parsed.notes ?? '',
    }

    return NextResponse.json(result)
  } catch (err) {
    if (err instanceof DecodeError) return NextResponse.json({ error: err.message }, { status: err.status })
    console.error('Decode error', err)
    const message = err instanceof Error ? err.message : 'Unknown error contacting the model.'
    return NextResponse.json({ error: `Decoding failed: ${message}` }, { status: 502 })
  }
}
