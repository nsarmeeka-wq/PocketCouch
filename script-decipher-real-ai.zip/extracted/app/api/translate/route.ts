import { NextRequest, NextResponse } from 'next/server'
import type Anthropic from '@anthropic-ai/sdk'
import { anthropicClient, decodeModel, parseJsonResponse, DecodeError } from '@/lib/ai'

export const runtime = 'nodejs'
export const maxDuration = 30

type TranslateResult = { translation: string }

export async function POST(req: NextRequest) {
  const anthropic = anthropicClient()
  if (!anthropic) {
    return NextResponse.json(
      { error: 'This server is missing ANTHROPIC_API_KEY. Add it to your environment (see .env.example) and restart the app.' },
      { status: 500 },
    )
  }

  let body: { text?: string; sourceLanguage?: string; targetLanguage?: string }
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: 'Invalid request body.' }, { status: 400 })
  }

  const { text, sourceLanguage = 'the original language', targetLanguage } = body
  if (!text || !text.trim()) return NextResponse.json({ translation: '' })
  if (!targetLanguage) return NextResponse.json({ error: 'A target language is required.' }, { status: 400 })

  const prompt = `Translate the following text from ${sourceLanguage} into ${targetLanguage}. Preserve line breaks, tone, and register as closely as natural phrasing allows.

Respond with ONLY a single JSON object, no markdown fences, no commentary: { "translation": string }

Text to translate:
"""
${text}
"""`

  try {
    const message = await anthropic.messages.create({
      model: decodeModel(),
      max_tokens: 2000,
      messages: [{ role: 'user', content: prompt }],
    })
    const textBlock = message.content.find((block): block is Anthropic.TextBlock => block.type === 'text')
    if (!textBlock) throw new DecodeError('The model did not return a text response.')

    let parsed: Partial<TranslateResult>
    try {
      parsed = parseJsonResponse<Partial<TranslateResult>>(textBlock.text)
    } catch {
      throw new DecodeError('Could not parse the model\u2019s response. Please try again.')
    }

    return NextResponse.json({ translation: parsed.translation ?? '' })
  } catch (err) {
    if (err instanceof DecodeError) return NextResponse.json({ error: err.message }, { status: err.status })
    console.error('Translate error', err)
    const message = err instanceof Error ? err.message : 'Unknown error contacting the model.'
    return NextResponse.json({ error: `Translation failed: ${message}` }, { status: 502 })
  }
}
