import Anthropic from '@anthropic-ai/sdk'

let client: Anthropic | null = null

/** Lazily construct the Anthropic client so a missing key fails per-request, not at build time. */
export function anthropicClient() {
  if (!process.env.ANTHROPIC_API_KEY) return null
  if (!client) client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })
  return client
}

export function decodeModel() {
  return process.env.ANTHROPIC_DECODE_MODEL || 'claude-sonnet-5'
}

/** Strip markdown code fences some models add around JSON despite instructions, then parse. */
export function parseJsonResponse<T>(text: string): T {
  const cleaned = text.trim().replace(/^```(?:json)?\s*/i, '').replace(/```\s*$/i, '').trim()
  return JSON.parse(cleaned) as T
}

export class DecodeError extends Error {
  status: number
  constructor(message: string, status = 502) {
    super(message)
    this.status = status
  }
}
