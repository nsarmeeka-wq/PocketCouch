'use client'

import { useEffect, useRef, useState } from 'react'
import { ArrowLeft, ArrowRight, BookOpen, Check, CheckCircle2, Copy, Download, FileJson, FileText, Globe2, Info, Languages, Layers3, Loader2, Save, ScanLine, Search, Sparkles, TriangleAlert, Volume2 } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Field, FieldGroup, FieldLabel } from '@/components/ui/field'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { ImageViewer, UploadZone } from '@/components/manuscript-upload'
import { downloadFile, translationLocale, type Manuscript, type Script, type TranslationLanguage } from '@/lib/manuscripts'
import { TranslationLanguageSelect } from '@/components/translation-language-select'
import { cn } from '@/lib/utils'

const stages = ['Enhancing manuscript image', 'Locating handwritten text', 'Identifying the script', 'Transcribing to Unicode', 'Translating and extracting insights']

type DecodeResponse = {
  script: Script
  language: string
  transcription: string
  translation: string
  subject: string
  confidence: number
  notes: string
}

function emptyDraft(image: string, title: string): Manuscript {
  return { id: crypto.randomUUID(), title, script: 'Devanagari', language: '', subject: '', period: '', location: '', image, text: '', translations: {}, confidence: 0, date: new Date().toISOString().slice(0, 10) }
}

export function DecoderWorkspace({ initial, initialComplete = false, onSave }: { initial?: Manuscript; initialComplete?: boolean; onSave: (item: Manuscript) => void }) {
  const [item, setItem] = useState<Manuscript | undefined>(initial)
  const [phase, setPhase] = useState<'upload' | 'ready' | 'processing' | 'complete'>(initial ? (initialComplete ? 'complete' : 'ready') : 'upload')
  const [progress, setProgress] = useState(0)
  const [language, setLanguage] = useState<TranslationLanguage>(initial?.preferredTranslation ?? 'English')
  const locale = translationLocale(language)
  const [query, setQuery] = useState('')
  const [decodeError, setDecodeError] = useState<string | null>(null)
  const [translating, setTranslating] = useState(false)
  const transcription = useRef<HTMLTextAreaElement>(null)
  const stageTimer = useRef<ReturnType<typeof setInterval> | null>(null)
  const abortRef = useRef<AbortController | null>(null)
  const complete = phase === 'complete'
  const running = phase === 'processing'

  useEffect(() => () => { if (stageTimer.current) clearInterval(stageTimer.current); abortRef.current?.abort() }, [])
  useEffect(() => () => { if ('speechSynthesis' in window) window.speechSynthesis.cancel() }, [])

  function chooseSample(sample: Manuscript) { setItem({ ...emptyDraft(sample.image, sample.title), id: sample.id }); setDecodeError(null); setPhase('ready'); setProgress(0) }
  function update(field: keyof Manuscript, value: string) { if (item) setItem({ ...item, [field]: value }) }

  async function runDecode() {
    if (!item) return
    setPhase('processing'); setDecodeError(null); setProgress(0)
    const controller = new AbortController()
    abortRef.current = controller
    stageTimer.current = setInterval(() => setProgress(value => Math.min(92, value + 4)), 220)
    try {
      const res = await fetch('/api/decode', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ image: item.image, targetLanguage: language }),
        signal: controller.signal,
      })
      const data: DecodeResponse & { error?: string } = await res.json()
      if (!res.ok) throw new Error(data.error || 'Decoding failed. Please try again.')
      if (stageTimer.current) clearInterval(stageTimer.current)
      setProgress(100)
      setItem(prev => prev && {
        ...prev,
        script: data.script,
        language: data.language,
        subject: data.subject,
        text: data.transcription,
        translations: { [language]: data.translation },
        confidence: data.confidence,
        notes: data.notes,
      })
      setPhase('complete')
      toast.success(data.confidence < 60 ? 'Decoding complete — low confidence' : 'Decoding complete', { description: data.notes || 'Review the transcription before relying on it.' })
    } catch (err) {
      if (stageTimer.current) clearInterval(stageTimer.current)
      if (err instanceof DOMException && err.name === 'AbortError') return
      const message = err instanceof Error ? err.message : 'Something went wrong contacting the model.'
      setDecodeError(message)
      setProgress(0)
      setPhase('ready')
      toast.error('Decoding failed', { description: message })
    }
  }

  function cancelDecode() {
    abortRef.current?.abort()
    if (stageTimer.current) clearInterval(stageTimer.current)
    setPhase('ready'); setProgress(0)
  }

  async function selectLanguage(next: TranslationLanguage) {
    setLanguage(next)
    if (!item || item.translations[next]) return
    setTranslating(true)
    try {
      const res = await fetch('/api/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: item.text, sourceLanguage: item.language, targetLanguage: next }),
      })
      const data: { translation?: string; error?: string } = await res.json()
      if (!res.ok) throw new Error(data.error || 'Translation failed.')
      setItem(prev => prev && { ...prev, translations: { ...prev.translations, [next]: data.translation ?? '' } })
    } catch (err) {
      toast.error('Translation failed', { description: err instanceof Error ? err.message : 'Please try again.' })
    } finally {
      setTranslating(false)
    }
  }

  function searchText() {
    if (!item || !query.trim()) return
    const index = item.text.toLocaleLowerCase().indexOf(query.toLocaleLowerCase())
    if (index === -1) { toast.info('No matching text found'); return }
    transcription.current?.focus(); transcription.current?.setSelectionRange(index, index + query.length)
  }
  async function copy() { try { await navigator.clipboard.writeText(item?.text || ''); toast.success('Transcription copied') } catch { toast.error('Clipboard unavailable. Select the text and copy it manually.') } }
  function listen() {
    if (!('speechSynthesis' in window) || !item) { toast.error('Text-to-speech is not supported by this browser.'); return }
    window.speechSynthesis.cancel()
    const utterance = new SpeechSynthesisUtterance(item.text)
    const speechLocales: Partial<Record<Script, string>> = { Tamil: 'ta-IN', Bengali: 'bn-IN', Kannada: 'kn-IN', Telugu: 'te-IN', Odia: 'or-IN', 'Perso-Arabic': 'fa-IR' }
    utterance.lang = speechLocales[item.script] ?? 'hi-IN'
    utterance.onerror = () => toast.error('No suitable voice is available. Try a browser with an Indic language voice installed.')
    window.speechSynthesis.speak(utterance)
    toast.info('Reading transcription', { description: 'Pronunciation depends on your browser’s installed voices.' })
  }
  function exportMetadata(format: 'json' | 'csv') {
    if (!item) return
    const metadata = { title: item.title, script: item.script, language: item.language, subject: item.subject, period: item.period, location: item.location, confidence: item.confidence, date: item.date, source: 'AI-decoded (Claude)' }
    if (format === 'json') downloadFile(JSON.stringify(metadata, null, 2), 'manuscript-metadata.json', 'application/json')
    else {
      const escape = (v: unknown) => { const str = String(v); return `"${(/^[=+@\-\t\r]/.test(str) ? "'" + str : str).replaceAll('"', '""')}"` }
      downloadFile(Object.keys(metadata).join(',') + '\n' + Object.values(metadata).map(escape).join(','), 'manuscript-metadata.csv', 'text/csv;charset=utf-8')
    }
  }

  const translationText = item?.translations[language]

  return <div className="flex flex-col gap-7">
    <div className="no-print flex flex-wrap items-center justify-between gap-4"><div><p className="eyebrow">The discovery workspace</p><h1 className="mt-3 font-serif text-4xl font-medium">{phase === 'upload' ? 'Unlock a page of history.' : complete ? 'Ancient words. New possibilities.' : 'A little closer to the past.'}</h1><p className="mt-3 text-sm leading-6 text-muted-foreground">Upload, explore, and bring your manuscript into the digital world.</p></div><Badge variant="outline"><Sparkles data-icon="inline-start" />AI-powered</Badge></div>
    <Alert className="no-print"><Info /><AlertDescription>Your image is sent to Claude for transcription and translation. Handwriting recognition — especially of historical or damaged manuscripts — can be wrong. Review the results carefully, and don&apos;t treat script, dates, or provenance as verified without expert review.</AlertDescription></Alert>
    {phase === 'upload' ? <UploadZone onSample={chooseSample} onUpload={(image, name) => { setItem(emptyDraft(image, name)); setDecodeError(null); setPhase('ready') }} /> : item && <>
      <div className="no-print flex flex-wrap items-center justify-between gap-4"><Button variant="ghost" onClick={() => { if (running) cancelDecode(); setPhase('upload'); setItem(undefined); setProgress(0); setDecodeError(null) }}><ArrowLeft data-icon="inline-start" />{running ? 'Cancel and start again' : 'New manuscript'}</Button><div className="flex flex-wrap items-center gap-3">{!complete && !running && <TranslationLanguageSelect value={language} onChange={setLanguage} />}{phase === 'ready' && <Button onClick={runDecode} className="h-10 px-5"><Sparkles data-icon="inline-start" />Decode manuscript<ArrowRight data-icon="inline-end" /></Button>}{complete && <Button className="h-10 px-4" onClick={() => onSave({ ...item, preferredTranslation: language })}><Save data-icon="inline-start" />Save to session collection</Button>}</div></div>
      {decodeError && <Alert variant="destructive" className="no-print"><TriangleAlert /><AlertDescription>{decodeError}</AlertDescription></Alert>}
      <Tabs defaultValue="results">
        {complete && <TabsList className="no-print mb-4"><TabsTrigger value="results"><FileText />Results</TabsTrigger><TabsTrigger value="compare"><Layers3 />Compare versions</TabsTrigger></TabsList>}
        <TabsContent value="results">
          <div className="grid items-start gap-5 xl:grid-cols-[1fr_.78fr_1fr]">
            <ImageViewer image={item.image} scanning={running} />
            <section className="panel overflow-hidden"><h2 className="panel-heading"><span className="flex items-center gap-2"><Sparkles className="size-4 text-primary" />Decoding journey</span></h2><div className="flex flex-col gap-6 p-5"><div className="flex flex-col items-center gap-3 py-3"><span className={cn('flex size-16 items-center justify-center rounded-2xl border border-primary/30 bg-primary/10 text-primary', running && 'animate-pulse')}>{complete ? <CheckCircle2 className="size-7" strokeWidth={1.5} /> : <ScanLine className="size-7" strokeWidth={1.5} />}</span><p className="text-center font-serif text-2xl">{complete ? 'A new chapter, unlocked.' : running ? 'Awakening ancient knowledge…' : 'Ready for discovery.'}</p><p className="text-center text-xs leading-5 text-muted-foreground">{complete ? 'Claude\u2019s results are ready to review.' : running ? 'Claude is reading your image now.' : 'Run the decoder to get a real AI transcription.'}</p></div>
              <ol className="flex flex-col gap-5">{stages.map((step, i) => { const done = complete || progress >= (i + 1) * 20; const active = running && Math.floor(progress / 20) === i; return <li key={step} className={cn('flex items-center gap-3 text-xs', done || active ? 'text-foreground' : 'text-muted-foreground')}><span className={cn('flex size-6 shrink-0 items-center justify-center rounded-full border', done ? 'border-primary/30 bg-primary/10 text-primary' : 'border-border')}>{done ? <Check className="size-3" /> : active ? <Loader2 className="size-3 animate-spin" /> : i + 1}</span>{step}</li> })}</ol>
              <div aria-live="polite"><div className="mb-3 flex justify-between text-xs text-muted-foreground"><span>{complete ? 'Complete' : running ? 'Decoding…' : 'Not started'}</span><span>{complete ? 100 : progress}%</span></div><Progress aria-label="Decoding progress" value={complete ? 100 : progress} /></div>
              {complete && <div className="rounded-lg border border-primary/20 bg-primary/5 p-4"><p className="text-xs text-muted-foreground">Detected script</p><p className="mt-2 flex items-center justify-between text-sm"><span>{item.script}{item.language && ` · ${item.language}`}</span><CheckCircle2 className="size-4 text-primary" /></p><p className="mt-2 text-xs text-primary">{item.confidence}% model confidence</p></div>}
            </div></section>
            <section className="panel flex min-h-[570px] flex-col overflow-hidden"><h2 className="panel-heading"><span>Digital transcription</span><Languages className="size-4 text-primary" /></h2>{complete ? <><div className="flex flex-wrap items-center justify-between gap-2 border-b border-border p-3"><Badge variant="secondary">{item.script}</Badge><div className="flex items-center gap-1"><Button variant="ghost" size="icon" aria-label="Copy transcription" onClick={copy}><Copy /></Button><Button variant="ghost" size="icon" aria-label="Listen to transcription" onClick={listen}><Volume2 /></Button></div></div><textarea ref={transcription} aria-label="Editable Unicode transcription" value={item.text} onChange={e => update('text', e.target.value)} className="min-h-64 flex-1 resize-y rounded-none border-0 bg-card p-5 text-lg leading-[2]" /><div className="no-print flex items-center gap-2 border-t border-border p-3"><input aria-label="Search transcription" placeholder="Find in transcription…" value={query} onChange={e => setQuery(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && !e.nativeEvent.isComposing && e.keyCode !== 229) searchText() }} className="h-9 min-w-0 flex-1 px-3 text-xs" /><Button variant="ghost" size="icon" aria-label="Find text" onClick={searchText}><Search /></Button></div><p className="border-t border-border px-5 py-4 text-xs text-muted-foreground">Model confidence <span className="float-none ml-2 text-primary">{item.confidence}%</span> · Editable Unicode · Edits here do not re-run OCR</p></> : <div className="flex flex-1 flex-col items-center justify-center gap-4 p-8 text-center"><FileText className="size-9 text-primary/40" strokeWidth={1} /><p className="font-serif text-2xl">Words waiting to be found.</p><p className="text-xs leading-6 text-muted-foreground">{running ? 'Your transcription will appear when decoding completes.' : 'Run the decoder to see a real Unicode transcription of your image.'}</p></div>}</section>
          </div>
          {complete && <div className="mt-6 grid gap-5 lg:grid-cols-2"><section className="panel overflow-hidden"><div className="panel-heading flex-wrap gap-3"><h2 className="flex items-center gap-2"><Globe2 className="size-4 text-primary" />Modern translation</h2><TranslationLanguageSelect value={language} onChange={lang => void selectLanguage(lang)} /></div>{translating ? <div className="flex h-40 items-center justify-center gap-2 text-sm text-muted-foreground"><Loader2 className="size-4 animate-spin" />Translating…</div> : <textarea aria-label="Editable translation" lang={locale.code} dir={locale.direction} value={translationText ?? ''} onChange={e => setItem({ ...item, translations: { ...item.translations, [language]: e.target.value } })} className="h-40 w-full resize-y rounded-none border-0 bg-card p-5 text-base leading-8" />}<div className="flex flex-col gap-3 border-t border-border p-5"><p className="text-sm leading-6 text-muted-foreground">AI-generated translation · Edits to the transcription do not retranslate automatically.</p><Button variant="outline" className="no-print self-start" disabled={!translationText} onClick={() => translationText && downloadFile(translationText, `script-decipher-${item.script.toLowerCase()}-${locale.code}-translation.txt`)}><Download data-icon="inline-start" />Download {language} translation</Button></div></section><section className="panel overflow-hidden"><h2 className="panel-heading"><span className="flex items-center gap-2"><BookOpen className="size-4 text-primary" />What the model noticed</span></h2><div className="flex flex-col gap-4 p-5"><p className="text-sm leading-7 text-muted-foreground">Apparent subject: <span className="text-foreground">{item.subject || 'Not determined'}</span></p>{item.notes && <Alert><Info /><AlertDescription>{item.notes}</AlertDescription></Alert>}<p className="text-xs text-muted-foreground">This is Claude&apos;s own reading of your image, not a verified historical classification. Confirm anything important with a specialist.</p></div></section></div>}
        </TabsContent>
        <TabsContent value="compare"><div className="grid gap-5 lg:grid-cols-3"><ImageViewer image={item.image} /><section className="panel"><h2 className="panel-heading">Unicode transcription</h2><p className="whitespace-pre-wrap p-6 text-xl leading-[2]">{item.text}</p></section><section className="panel"><div className="panel-heading flex-wrap gap-3"><h2>Translation</h2><TranslationLanguageSelect value={language} onChange={lang => void selectLanguage(lang)} /></div><p lang={locale.code} dir={locale.direction} className="whitespace-pre-wrap p-6 text-lg leading-9">{translationText ?? (translating ? 'Translating…' : '')}</p></section></div></TabsContent>
      </Tabs>
      {complete && <>
        <section className="panel overflow-hidden"><h2 className="panel-heading"><span>Manuscript metadata</span><Badge variant="outline">Editable</Badge></h2><div className="p-5"><FieldGroup className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{[{ label: 'Title', key: 'title' }, { label: 'Language', key: 'language' }, { label: 'Subject', key: 'subject' }, { label: 'Period (your input)', key: 'period' }, { label: 'Location (your input)', key: 'location' }].map(({ label, key }) => <Field key={key}><FieldLabel htmlFor={`meta-${key}`}>{label}</FieldLabel><input id={`meta-${key}`} className="h-10 px-3 text-sm" value={item[key as keyof Manuscript] as string} onChange={e => update(key as keyof Manuscript, e.target.value)} /></Field>)}<Field><FieldLabel htmlFor="meta-script">Script</FieldLabel><select id="meta-script" className="h-10 px-3 text-sm" value={item.script} onChange={e => update('script', e.target.value as Script)}>{['Devanagari', 'Tamil', 'Bengali', 'Kannada', 'Telugu', 'Odia', 'Perso-Arabic'].map(script => <option key={script}>{script}</option>)}</select></Field></FieldGroup></div><p className="border-t border-border px-5 py-3 text-xs text-muted-foreground">Script, language, and transcription are Claude&apos;s reading of the image and may contain errors. Period and location are not estimated by the model — enter them yourself if known, and verify with a specialist before treating them as fact.</p></section>
        <section className="no-print"><div className="mb-5"><p className="eyebrow">Keep the knowledge alive</p><h2 className="mt-3 font-serif text-3xl">Preserve & export</h2></div><div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">{[{ icon: FileText, title: 'Unicode text', note: 'Editable, portable .txt', action: () => downloadFile(item.text, 'manuscript-transcription.txt'), cta: 'Download TXT' }, { icon: FileText, title: 'Research document', note: 'Use “Save as PDF” in print', action: () => window.print(), cta: 'Print / save PDF' }, { icon: FileJson, title: 'Structured metadata', note: 'For catalogs and research', action: () => exportMetadata('json'), cta: 'Download JSON' }, { icon: Download, title: 'Spreadsheet metadata', note: 'A portable .csv record', action: () => exportMetadata('csv'), cta: 'Download CSV' }].map(({ icon: Icon, title, note, action, cta }) => <div key={title} className="panel flex flex-col items-start gap-3 p-5"><Icon className="size-6 text-primary" strokeWidth={1.4} /><h3 className="text-sm font-medium">{title}</h3><p className="text-xs text-muted-foreground">{note}</p><Button variant="outline" onClick={action} className="mt-1 w-full">{cta}<Download data-icon="inline-end" /></Button></div>)}</div></section>
      </>}
    </>}
  </div>
}
